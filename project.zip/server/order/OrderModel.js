const mongoose = require("mongoose")
const orderSchema=mongoose.Schema({
    userId:{type:mongoose.Schema.Types.ObjectId, ref:"userModel", default:null},
    totalPrice:{type:Number, default:0},totalPrice:{type:Number, default:0},
    address:{type:String,default:""},
    orderDetails:[
       { 
            productId:{type:mongoose.Schema.Types.ObjectId, ref:"product",default:null},
            price:{type:Number, default:0},
            quantity:{type:Number, default:1},
            total:{type:Number, default:0},
        }
    ],
    orderStatus:{type:Number, default:1},
    status:{type:Boolean, default:true},
    createdAt:{type:Date, default:Date.now()}
})
module.exports=mongoose.model("OrderModel", orderSchema)